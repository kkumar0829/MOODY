package com.example.moody;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class SplashScreen extends Activity {
MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        Log.i("MY IIT APP","MY SPLASH STATED");
        mp=MediaPlayer.create(this, R.raw.musc0);
        mp.start();
        Thread t=new Thread()
        {
        	public void run()
        	{
        		try{
        			sleep(5000);
        			Intent i=new Intent(SplashScreen.this,MainScreen.class);
        			startActivity(i);
        		}
        		catch(Exception e){}
        	}
        };
        t.start();
        
    }
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		mp.release();
		finish();
	}
}
