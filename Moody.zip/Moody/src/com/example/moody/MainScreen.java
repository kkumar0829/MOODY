package com.example.moody;

import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainScreen extends Activity {
	Button b1,b2,b3,b4;
	TextView tt0,tt1,tt2;
	MediaPlayer mp;
	
	 double startTime = 0;
	 double finalTime = 0;
	  Handler myHandler = new Handler();;
	   int forwardTime = 6000;
	  int backwardTime = 6000;
	 SeekBar seekbar;
	 static int oneTimeOnly = 0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_screen);
		 b1 = (Button) findViewById(R.id.fwd_button);
	      b2 = (Button) findViewById(R.id.pause_button);
	      b3 = (Button)findViewById(R.id.play_button);
	      b4 = (Button)findViewById(R.id.back_button);
	      
	      tt0 = (TextView)findViewById(R.id.first_time);
	      tt1 = (TextView)findViewById(R.id.full_time);
	      tt2 = (TextView)findViewById(R.id.time_text);
	       
	      tt2.setText("                              Tum Mere Ho..          ");
	      
	      mp = MediaPlayer.create(this, R.raw.musc1);
	      seekbar = (SeekBar)findViewById(R.id.seekBar1);
	      seekbar.setClickable(false);
	      b2.setEnabled(false);
	      
	      b3.setOnClickListener(new View.OnClickListener() {
	          @Override
	          public void onClick(View v) {
	             Toast.makeText(getApplicationContext(), "Playing",Toast.LENGTH_SHORT).show();
	             mp.start();

	             finalTime = mp.getDuration();
	             startTime = mp.getCurrentPosition();

	             if (oneTimeOnly == 0) {
	                seekbar.setMax((int) finalTime);
	                oneTimeOnly = 1;
	             }
	 				
	             tt1.setText(String.format("%d min, %d sec",TimeUnit.MILLISECONDS.toMinutes((long) finalTime),TimeUnit.MILLISECONDS.toSeconds((long) finalTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) finalTime))));
	      
	             tt0.setText(String.format("%d min, %d sec",TimeUnit.MILLISECONDS.toMinutes((long) startTime),TimeUnit.MILLISECONDS.toSeconds((long) startTime) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long) startTime))));

	                  seekbar.setProgress((int)startTime);
	                  myHandler.postDelayed(UpdateSongTime,100);
	                  b2.setEnabled(true);
	                  b3.setEnabled(false);
	               }
	            });
	      
	      b2.setOnClickListener(new View.OnClickListener() {
	          @Override
	          public void onClick(View v) {
	             Toast.makeText(getApplicationContext(), "Paused",Toast.LENGTH_SHORT).show();
	             mp.pause();
	             b2.setEnabled(false);
	             b3.setEnabled(true);
	          }
	       });
	      
	      b1.setOnClickListener(new View.OnClickListener() {
	          @Override
	          public void onClick(View v) {
	             int temp = (int)startTime;

	             if((temp+forwardTime)<=finalTime){
	                startTime = startTime + forwardTime;
	                mp.seekTo((int) startTime);
	               // Toast.makeText(getApplicationContext(),"You have Jumped forward 5 seconds",Toast.LENGTH_SHORT).show();
	             }else{
	               // Toast.makeText(getApplicationContext(),"Cannot jump forward 5seconds",Toast.LENGTH_SHORT).show();
	             }
	          }
	       });

	       b4.setOnClickListener(new View.OnClickListener() {
	          @Override
	          public void onClick(View v) {
	             int temp = (int)startTime;

	             if((temp-backwardTime)>0){
	                startTime = startTime - backwardTime;
	                mp.seekTo((int) startTime);
	                //Toast.makeText(getApplicationContext(),"You have Jumped backward 5  seconds",Toast.LENGTH_SHORT).show();
	             }else{
	                //Toast.makeText(getApplicationContext(),"Cannot jump backward 5  seconds",Toast.LENGTH_SHORT).show();
	             }
	          }
	       });
	    }
	 Runnable UpdateSongTime = new Runnable() {
	      public void run() {
	         startTime = mp.getCurrentPosition();
	         tt0.setText(String.format("%d min, %d sec",
	            TimeUnit.MILLISECONDS.toMinutes((long) startTime),
	            TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
	            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.
	            toMinutes((long) startTime))));
	         seekbar.setProgress((int)startTime);
	         myHandler.postDelayed(this, 100);
	      }
	   };
	      
	      
	      
	      
	      
	}
